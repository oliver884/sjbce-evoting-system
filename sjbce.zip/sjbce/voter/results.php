<?php
require_once __DIR__ . '/../config/config.php';
require_student_login();
$pdo = get_db();

$elections = $pdo->query(
    "SELECT * FROM elections WHERE status IN ('active','ended') ORDER BY start_time DESC"
)->fetchAll();

$pageTitle = 'Results';
require __DIR__ . '/../includes/header_site.php';
?>

<h1>Election Results</h1>

<?php if (!$elections): ?>
  <div class="card text-center" style="padding:3rem;">
    <p class="muted">No results to show yet.</p>
  </div>
<?php endif; ?>

<?php foreach ($elections as $election):
    $isEnded = $election['status'] === 'ended';

    $stmt = $pdo->prepare('SELECT * FROM positions WHERE election_id = ? ORDER BY display_order, id');
    $stmt->execute([$election['id']]);
    $positions = $stmt->fetchAll();
?>
  <div class="card mb-lg">
    <span class="badge badge-<?= $isEnded ? 'ended' : 'active' ?>"><?= $isEnded ? 'Final Results' : 'Live — Voting Still Open' ?></span>
    <h2 style="margin:.5rem 0 0;"><?= h($election['title']) ?></h2>
  </div>

  <?php foreach ($positions as $pos):
      $stmt = $pdo->prepare(
          'SELECT c.id, c.full_name, COUNT(v.id) AS votes
           FROM candidates c LEFT JOIN votes v ON v.candidate_id = c.id
           WHERE c.position_id = ? GROUP BY c.id ORDER BY votes DESC'
      );
      $stmt->execute([$pos['id']]);
      $candidates = $stmt->fetchAll();
      $totalVotes = array_sum(array_column($candidates, 'votes'));

      $topVoteCount = $candidates ? (int) $candidates[0]['votes'] : 0;
      $winners = $topVoteCount > 0 ? array_filter($candidates, fn($c) => (int) $c['votes'] === $topVoteCount) : [];
      $isTie = count($winners) > 1;
  ?>
    <div class="card mb-lg">
      <div class="position-tag"><?= h($pos['title']) ?></div>

      <?php if ($isEnded && $winners): ?>
        <?php if ($isTie): ?>
          <div class="alert alert-info">
            🏆 <strong>Tie</strong> between <?= h(implode(', ', array_column($winners, 'full_name'))) ?>
            (<?= $topVoteCount ?> votes each)
          </div>
        <?php else: ?>
          <div class="alert alert-success">
            🏆 <strong>Winner: <?= h(reset($winners)['full_name']) ?></strong> (<?= $topVoteCount ?> votes)
          </div>
        <?php endif; ?>
      <?php endif; ?>

      <?php if (!$candidates): ?>
        <p class="muted">No candidates for this position.</p>
      <?php endif; ?>

      <?php foreach ($candidates as $c):
          $pct = $totalVotes > 0 ? round(($c['votes'] / $totalVotes) * 100, 1) : 0;
          $isWinner = in_array($c, $winners, true);
      ?>
        <div style="margin-bottom:.9rem;">
          <div class="flex-between" style="margin-bottom:.25rem;">
            <span style="font-weight:600;">
              <?= h($c['full_name']) ?>
              <?php if ($isWinner): ?>
                <span class="badge badge-active">
                  <?= $isEnded ? ($isTie ? 'Tied' : 'Winner') : ($isTie ? 'Tied for Lead' : 'Leading') ?>
                </span>
              <?php endif; ?>
            </span>
            <span class="muted"><?= $c['votes'] ?> votes (<?= $pct ?>%)</span>
          </div>
          <div class="turnout-bar"><div class="fill" style="width:<?= $pct ?>%;"></div></div>
        </div>
      <?php endforeach; ?>
    </div>
  <?php endforeach; ?>

<?php endforeach; ?>

<?php require __DIR__ . '/../includes/footer_site.php'; ?>
