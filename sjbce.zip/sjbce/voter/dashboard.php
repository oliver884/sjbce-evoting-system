<?php
require_once __DIR__ . '/../config/config.php';
require_student_login();
$pdo = get_db();
$studentId = current_student_id();

// Show every election the admin has marked "active" — regardless of its
// scheduled start/end time. Whether voting is actually allowed right now
// is decided separately below, per election.
$elections = $pdo->query(
    "SELECT * FROM elections WHERE status = 'active' ORDER BY start_time ASC"
)->fetchAll();

// All positions this student has already voted for, across all elections
$stmt = $pdo->prepare('SELECT position_id FROM votes WHERE student_id = ?');
$stmt->execute([$studentId]);
$votedPositionIds = array_column($stmt->fetchAll(), 'position_id');

$now = new DateTime();

$pageTitle = 'Voter Dashboard';
require __DIR__ . '/../includes/header_site.php';
?>

<h1>Welcome to TESCON General Election Portal</h1>

<?php if (!$elections): ?>
  <div class="card text-center" style="padding:3rem;">
    <h3>No election is currently open</h3>
    <p class="muted">Check back when voting opens. You'll see your ballot here.</p>
  </div>
<?php else: ?>

  <?php foreach ($elections as $election):
      $start = new DateTime($election['start_time']);
      $end   = new DateTime($election['end_time']);

      $notYetOpen  = $now < $start;
      $windowEnded = $now > $end;
      $votingOpen  = !$notYetOpen && !$windowEnded;

      $stmt = $pdo->prepare('SELECT * FROM positions WHERE election_id = ? ORDER BY display_order, id');
      $stmt->execute([$election['id']]);
      $positions = $stmt->fetchAll();

      $stmt = $pdo->prepare('SELECT COUNT(*) c FROM votes WHERE election_id = ?');
      $stmt->execute([$election['id']]);
      $totalVotes = (int) $stmt->fetch()['c'];

      // Countdown target: time until voting OPENS if it hasn't started yet,
      // otherwise time until voting CLOSES.
      $countdownTarget = $notYetOpen ? $election['start_time'] : $election['end_time'];
      $countdownIso = date('c', strtotime($countdownTarget));
      $countdownLabel = $notYetOpen ? 'VOTING OPENS IN' : ($windowEnded ? 'VOTING CLOSED' : 'POLLS CLOSING');
  ?>

    <div class="countdown-card mb-lg">
      <div class="flex-between" style="align-items:flex-start;flex-wrap:wrap;gap:1rem;">
        <div>
          <?php if ($votingOpen): ?>
            <span class="badge badge-active">Voting Open</span>
          <?php elseif ($notYetOpen): ?>
            <span class="badge badge-pending">Opens <?= format_datetime($election['start_time']) ?></span>
          <?php else: ?>
            <span class="badge badge-ended">Voting Window Closed</span>
          <?php endif; ?>
          <h2 style="margin:.5rem 0 0;color:var(--white);"><?= h($election['title']) ?></h2>
          <p style="margin:.25rem 0 0;color:var(--sky-tint);opacity:.85;">
            <?= format_datetime($election['start_time']) ?> &rarr; <?= format_datetime($election['end_time']) ?>
          </p>
        </div>
        <?php if (!$windowEnded): ?>
          <div class="countdown-timer" data-end="<?= h($countdownIso) ?>">
            <div class="cd-label"><span class="cd-dot"></span> <?= $countdownLabel ?> <span class="cd-live">LIVE</span></div>
            <div class="cd-boxes">
              <div class="cd-box"><span class="cd-days">--</span><small>DAYS</small></div>
              <div class="cd-box"><span class="cd-hours">--</span><small>HRS</small></div>
              <div class="cd-box"><span class="cd-mins">--</span><small>MIN</small></div>
              <div class="cd-box"><span class="cd-secs">--</span><small>SEC</small></div>
            </div>
          </div>
        <?php endif; ?>
      </div>
      <div class="cd-vote-count">
        <strong><?= $totalVotes ?></strong> total <?= $totalVotes === 1 ? 'vote' : 'votes' ?> cast so far
        <?php if ($notYetOpen): ?> · <span style="color:var(--white);">Voting hasn't started yet — buttons are disabled until it opens.</span><?php endif; ?>
        <?php if ($windowEnded): ?> · <span style="color:var(--white);">This election's voting window has ended.</span><?php endif; ?>
      </div>
    </div>

    <div class="section-title"><h3>Positions — <?= h($election['title']) ?></h3></div>

    <?php if (!$positions): ?>
      <div class="card mb-lg"><p class="muted">No positions have been set up yet for this election.</p></div>
    <?php else: ?>
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:1rem;margin-bottom:2rem;">
        <?php foreach ($positions as $p):
            $voted = in_array($p['id'], $votedPositionIds);
        ?>
          <div class="card">
            <div class="position-tag"><?= h($p['title']) ?></div>
            <?php if ($voted): ?>
              <p class="muted">You have already voted for this position.</p>
              <span class="badge badge-active">Vote Recorded</span>
            <?php elseif (!$votingOpen): ?>
              <p class="muted"><?= $notYetOpen ? 'Voting has not started yet.' : 'Voting has closed for this election.' ?></p>
              <button class="btn btn-primary btn-sm" disabled>Vote Now</button>
            <?php else: ?>
              <p class="muted">Cast your vote for this position.</p>
              <a href="<?= BASE_URL ?>voter/vote.php?position_id=<?= $p['id'] ?>" class="btn btn-primary btn-sm">Vote Now</a>
            <?php endif; ?>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

  <?php endforeach; ?>

  <script>
    // Live countdown — ticks every second in the browser, no server round-trip needed.
    document.querySelectorAll('.countdown-timer').forEach(function (el) {
      var end = new Date(el.dataset.end).getTime();

      function tick() {
        var diff = end - Date.now();
        if (diff < 0) diff = 0;

        var d = Math.floor(diff / 86400000);
        var h = Math.floor((diff % 86400000) / 3600000);
        var m = Math.floor((diff % 3600000) / 60000);
        var s = Math.floor((diff % 60000) / 1000);
        var pad = function (n) { return String(n).padStart(2, '0'); };

        el.querySelector('.cd-days').textContent  = pad(d);
        el.querySelector('.cd-hours').textContent = pad(h);
        el.querySelector('.cd-mins').textContent  = pad(m);
        el.querySelector('.cd-secs').textContent  = pad(s);

        if (diff === 0) {
          el.querySelector('.cd-label').innerHTML = 'TIME\'S UP — REFRESH';
          clearInterval(el._cdInterval);
        }
      }
      tick();
      el._cdInterval = setInterval(tick, 1000);
    });
  </script>

<?php endif; ?>

<?php require __DIR__ . '/../includes/footer_site.php'; ?>
