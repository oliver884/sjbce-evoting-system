<?php
require_once __DIR__ . '/../config/config.php';
require_student_login();
$pdo = get_db();
$studentId = current_student_id();

$positionId = (int) ($_GET['position_id'] ?? 0);

$stmt = $pdo->prepare('SELECT * FROM positions WHERE id = ?');
$stmt->execute([$positionId]);
$position = $stmt->fetch();

if (!$position) {
    flash_set('error', 'Position not found.');
    redirect(BASE_URL . 'voter/dashboard.php');
}

// Confirm the parent election is active
$stmt = $pdo->prepare("SELECT * FROM elections WHERE id = ? AND status = 'active'");
$stmt->execute([$position['election_id']]);
$election = $stmt->fetch();

if (!$election) {
    flash_set('error', 'This election is not currently open for voting.');
    redirect(BASE_URL . 'voter/dashboard.php');
}

// Already voted?
$stmt = $pdo->prepare('SELECT id FROM votes WHERE student_id = ? AND position_id = ?');
$stmt->execute([$studentId, $positionId]);
if ($stmt->fetch()) {
    flash_set('info', 'You have already voted for this position.');
    redirect(BASE_URL . 'voter/dashboard.php');
}

$stmt = $pdo->prepare('SELECT * FROM candidates WHERE position_id = ? AND is_approved = 1 ORDER BY full_name');
$stmt->execute([$positionId]);
$candidates = $stmt->fetchAll();

$pageTitle = h($position['title']);
require __DIR__ . '/../includes/header_site.php';
?>

<a href="<?= BASE_URL ?>voter/dashboard.php" class="muted" style="font-size:.85rem;">&larr; Back to dashboard</a>

<div class="position-tag" style="margin-top:1rem;"><?= h($position['title']) ?></div>
<h1>Choose your candidate</h1>
<p class="muted">You may vote for only one candidate. This action cannot be undone.</p>

<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:1rem;">
  <?php foreach ($candidates as $c): ?>
    <div class="ballot-stub">
      <div class="stub-photo" style="<?= $c['photo_path'] ? "background-image:url('" . h(UPLOAD_URL . $c['photo_path']) . "')" : '' ?>">
        <?= $c['photo_path'] ? '' : h(strtoupper(substr($c['full_name'], 0, 1))) ?>
      </div>
      <div class="stub-divider"></div>
      <div class="stub-body">
        <div class="stub-name"><?= h($c['full_name']) ?></div>
        <?php if ($c['manifesto']): ?><div class="stub-manifesto"><?= h($c['manifesto']) ?></div><?php endif; ?>
        <div class="stub-actions">
          <form method="post" action="<?= BASE_URL ?>voter/cast_vote.php" onsubmit="return confirm('Confirm your vote for <?= h(addslashes($c['full_name'])) ?>? This cannot be changed.');">
            <?= csrf_field() ?>
            <input type="hidden" name="position_id" value="<?= $positionId ?>">
            <input type="hidden" name="candidate_id" value="<?= $c['id'] ?>">
            <input type="hidden" name="election_id" value="<?= $election['id'] ?>">
            <button type="submit" class="btn btn-primary btn-sm">Vote for <?= h($c['full_name']) ?></button>
          </form>
        </div>
      </div>
    </div>
  <?php endforeach; ?>
  <?php if (!$candidates): ?>
    <div class="card"><p class="muted">No candidates listed for this position yet.</p></div>
  <?php endif; ?>
</div>

<?php require __DIR__ . '/../includes/footer_site.php'; ?>
