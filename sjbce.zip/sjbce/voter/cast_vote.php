<?php
require_once __DIR__ . '/../config/config.php';
require_student_login();

if (!is_post()) {
    redirect(BASE_URL . 'voter/dashboard.php');
}
verify_csrf();

$pdo = get_db();
$studentId   = current_student_id();
$positionId  = (int) ($_POST['position_id'] ?? 0);
$candidateId = (int) ($_POST['candidate_id'] ?? 0);
$electionId  = (int) ($_POST['election_id'] ?? 0);

if (!$positionId || !$candidateId || !$electionId) {
    flash_set('error', 'Invalid vote request.');
    redirect(BASE_URL . 'voter/dashboard.php');
}

try {
    $pdo->beginTransaction();

    // Re-check the election is active AND within its time window — never trust client state.
    $stmt = $pdo->prepare(
        "SELECT * FROM elections
         WHERE id = ? AND status = 'active' AND NOW() BETWEEN start_time AND end_time
         FOR UPDATE"
    );
    $stmt->execute([$electionId]);
    $election = $stmt->fetch();

    if (!$election) {
        $pdo->rollBack();
        flash_set('error', 'Voting is not currently open for this election.');
        redirect(BASE_URL . 'voter/dashboard.php');
    }

    // Confirm the candidate actually belongs to this position/election
    $stmt = $pdo->prepare(
        'SELECT id FROM candidates WHERE id = ? AND position_id = ? AND election_id = ? AND is_approved = 1'
    );
    $stmt->execute([$candidateId, $positionId, $electionId]);
    if (!$stmt->fetch()) {
        $pdo->rollBack();
        flash_set('error', 'That candidate is not valid for this position.');
        redirect(BASE_URL . 'voter/dashboard.php');
    }

    // Insert the vote — the UNIQUE(student_id, position_id) constraint is the real
    // safeguard against double-voting under concurrent requests.
    $stmt = $pdo->prepare(
        'INSERT INTO votes (election_id, position_id, candidate_id, student_id, voted_at, ip_address)
         VALUES (?, ?, ?, ?, NOW(), ?)'
    );
    $stmt->execute([$electionId, $positionId, $candidateId, $studentId, client_ip()]);

    $pdo->commit();

    log_action('student', $studentId, 'CAST_VOTE', "Position #$positionId, Candidate #$candidateId");
    flash_set('success', 'Your vote has been recorded. Thank you for voting.');
} catch (PDOException $e) {
    $pdo->rollBack();

    // MySQL error code 23000 = integrity constraint violation (duplicate vote)
    if ($e->getCode() === '23000') {
        flash_set('info', 'You have already voted for this position.');
    } else {
        error_log('Vote insert failed: ' . $e->getMessage());
        flash_set('error', 'Something went wrong recording your vote. Please try again.');
    }
}

redirect(BASE_URL . 'voter/dashboard.php');
