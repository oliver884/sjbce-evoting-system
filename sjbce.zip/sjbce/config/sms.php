<?php
/**
 * SMS configuration (bulk SMS gateway).
 *
 * Written for Arkesel (https://arkesel.com). Steps:
 *   1. Create an account and buy SMS credits.
 *   2. Register a Sender ID (max 11 characters, e.g. "SJBCE") and wait for approval.
 *   3. Copy your API key into SMS_API_KEY below.
 *
 * Using mNotify / Hubtel / another provider? Only sms_send_batch() in
 * includes/sms.php needs to change.
 */

define('SMS_API_KEY',   'ckVWV2JTeFpQZmFVZWNrSnd4ZEY');                // <-- your gateway API key
define('SMS_SENDER_ID', 'SJBCE');                               // <-- approved Sender ID (max 11 chars)
define('SMS_API_URL',   'https://sms.arkesel.com/api/v2/sms/send');

// Public address students should open from the SMS (must end with a slash).
// Leave '' to auto-detect — but on localhost that gives a useless localhost link,
// so set this to the live site address.
define('SMS_SITE_URL',  'https://sjbceelections.infinityfreeapp.com/sjbce/');

// ---- Automatic sending (cron/send_voting_sms.php) ----
// Secret that must be in the URL when a scheduler calls the script. Change it to your own long random text.
define('SMS_CRON_TOKEN', 'CHANGE_THIS_TO_A_LONG_RANDOM_TEXT');

// Sent once to ALL active students when an election's voting window opens.
define('SMS_AUTO_START_MESSAGE', "SJBCE Elections: Voting is now open! Go to https://sjbce.infinityfreeapp.com/student/login.php , enter your registered email to get an access code, then cast your vote.");

// Optional reminder to students who HAVEN'T voted yet. Set hours before closing, or 0 to turn it off.
define('SMS_REMINDER_HOURS', 24);
define('SMS_AUTO_REMINDER_MESSAGE', "SJBCE Elections: Voting closes soon and you haven't voted yet. Go to https://sjbce.infinityfreeapp.com/ to get your access code and vote.");
