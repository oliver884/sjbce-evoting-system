<?php
require_once __DIR__ . '/../config/config.php';
if (admin_logged_in()) {
    log_action('admin', current_admin_id(), 'LOGOUT', 'Admin logged out');
}
logout_all();
redirect(BASE_URL . 'admin/login.php');
