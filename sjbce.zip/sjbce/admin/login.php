<?php
require_once __DIR__ . '/../config/config.php';

if (admin_logged_in()) {
    redirect(BASE_URL . 'admin/dashboard.php');
}

$errors = [];

if (is_post()) {
    verify_csrf();
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = 'Enter both email and password.';
    } elseif ($lockoutMsg = login_rate_limit_check($email, 'admin')) {
        $errors[] = $lockoutMsg;
    } else {
        $admin = admin_attempt_login($email, $password);
        if ($admin) {
            admin_login($admin);
            log_action('admin', $admin['id'], 'LOGIN', 'Admin logged in');
            redirect(BASE_URL . 'admin/dashboard.php');
        } else {
            $errors[] = 'Invalid email or password.';
            login_rate_limit_record($email, 'admin');
            log_action('system', null, 'ADMIN_LOGIN_FAILED', 'Attempt for email: ' . $email);
        }
    }
}

$pageTitle = 'Admin Login';
require __DIR__ . '/../includes/header_site.php';
?>

<div class="auth-shell" style="min-height:70vh;">
  <div class="card" style="width:100%;max-width:400px;">
    <div class="position-tag">Administrator</div>
    <h2>Admin Login</h2>
    <p class="muted">Sign in to manage elections, candidates, and results.</p>

    <?php foreach ($errors as $e): ?>
      <div class="alert alert-error"><?= h($e) ?></div>
    <?php endforeach; ?>

    <form method="post" novalidate>
      <?= csrf_field() ?>
      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" required autofocus value="<?= old('email') ?>">
      </div>
      <div class="form-group">
        <label for="password">Password</label>
        <input type="password" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary btn-block">Log In</button>
    </form>
  </div>
</div>

<?php require __DIR__ . '/../includes/footer_site.php'; ?>
